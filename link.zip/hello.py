from logging import debug
from flask import Flask
from flask import render_template
from flask import request
from flask import jsonify
import numpy as np
import pandas as pd
from sqlalchemy import create_engine
app = Flask(__name__)

from utils import preprocess, kw_model, get_tags



tag_list = []
with open("tag_list.txt", "r") as file:
    for line in file.readlines():
        tag_list.append(line.replace("\n", ""))

tag_list = np.array(tag_list)
def query(tag_list):
    sql = "match (n:tag)-[r]-(m:article) where "
    for i in range(len(tag_list)):
        if i != len(tag_list) - 1:
            sql += "n.name=\"" + tag_list[i] + "\" or "
        else:
            sql += "n.name=\"" + tag_list[i] + "\" "
    # sql +=  "return n1 ,r ,n2"
    return sql

@app.route('/')
def hello_world():
    #ret = t.output(raw_text,ner_model, tokenizer, sim_model, sim_processor)
    return render_template('index.html')

@app.route('/tag_query', methods=['POST', 'GET'])
def tag_query():
    data = request.args.get('name')
    res = get_tags(data, tag_list, 100)

    sql = query(res)
    print(sql)


    return jsonify(answer = sql)

if __name__ == '__main__':
    app.run()
